import { Component, Input, OnInit } from '@angular/core';
import { Defect } from '../model/defect';
import { DefectsListService } from '../services/defects-list.service';
import { GenerateDefectsService } from '../services/generate-defects.service';

@Component({
  selector: 'app-edit-severity',
  templateUrl: './edit-severity.component.html',
  styleUrls: ['./edit-severity.component.css']
})
export class EditSeverityComponent implements OnInit {
  min: number;
  max: number;

  @Input()
  defect!: Defect;

  val:number = 1;
  constructor(private generateService: GenerateDefectsService,
              private defectsService: DefectsListService  
            ) { 
    this.min = this.generateService.minSeverity;
    this.max = this.generateService.maxSeverity;
  }

  ngOnInit(): void {
  }

  onSeverityChange(){
    this.defectsService.setDefectSeverity(this.defect.uuid, this.defect.severity);
  }

}
