import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EditSeverityComponent } from './edit-severity.component';

describe('EditSeverityComponent', () => {
  let component: EditSeverityComponent;
  let fixture: ComponentFixture<EditSeverityComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EditSeverityComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EditSeverityComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
