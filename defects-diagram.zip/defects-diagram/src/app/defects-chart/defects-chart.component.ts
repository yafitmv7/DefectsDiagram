import { Component, OnDestroy, OnInit, SimpleChanges, ViewChild } from '@angular/core';
import { ChartOptions, ChartDataset } from 'chart.js';
import { BaseChartDirective } from 'ng2-charts';
import { Subscription } from 'rxjs';
import { tap } from 'rxjs/operators';
import { Defect } from '../model/defect';
import { Panel } from '../model/panel';
import { DefectsListService } from '../services/defects-list.service';


@Component({
  selector: 'app-defects-chart',
  templateUrl: './defects-chart.component.html',
  styleUrls: ['./defects-chart.component.css']
})
export class DefectsChartComponent implements OnInit, OnDestroy {
  panel!: Panel;
  chartOptions?: ChartOptions;
  chartData?: ChartDataset[];
  legend = false;
  defects: Defect[] = [];
  selectedId: string | null = null;

  @ViewChild(BaseChartDirective)
  public chart?: BaseChartDirective;



  private defectsSubscription: Subscription | null = null;
  private selectedSubscription: Subscription | null = null;

  constructor(private defectsListService: DefectsListService) {
    this.defectsListService.getPanel().subscribe(panel => {
      this.panel = panel;
      this.chartOptions = {
        responsive: true,
        animation: {
          duration: 0
        },
        backgroundColor: (context) => {
          const index = context.dataIndex;
          if (this.defects[index]) {
            const color = (this.selectedId && this.defects[index].uuid == this.selectedId) ? '0,128,0' : '255,0,0';
            const opacity = this.defects[index].severity / 100; // by sevirity
            return `rgba(${color},${opacity})`;
          }
          return '255,0,0';
        },
        scales: {
          yAxes: {
            max: this.panel.height,
            min: 0,
          },
          xAxes: {
            max: this.panel.width,
            min: 0
          },
        },

      }
    });
  }

  ngOnInit(): void {
    this.defectsSubscription = this.defectsListService.getDefects()
      .pipe(
        tap(defects => this.defects = [...defects]),)
      .subscribe(_ => this.chartData = [{
        data: this.defects,
        pointRadius: 5
      }]);
    this.selectedSubscription = this.defectsListService.getSelectedId().subscribe(id => {
      this.selectedId = id
    });
  }

  onChartClicked(event: any) {
    if (event && event.active && event.active.length) {

      const index = event.active[0].index;
      if ((index || index === 0) && this.chartData) {
        const selectedDefect = this.defects[index];
        this.defectsListService.setSelectedId(selectedDefect.uuid);
        // console.log(selectedDefect.uuid)
        if (this.chart && this.chart.chart) {
          this.chart.chart.update();

        }

      }
    }
  }

  ngOnDestroy(): void {
    if (this.defectsSubscription) {
      this.defectsSubscription.unsubscribe();
      this.defectsSubscription = null;
    }
    if (this.selectedSubscription) {
      this.selectedSubscription.unsubscribe();
      this.selectedSubscription = null;
    }
  }


}
