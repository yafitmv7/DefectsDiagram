import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DefectsChartComponent } from './defects-chart.component';

describe('DefectsChartComponent', () => {
  let component: DefectsChartComponent;
  let fixture: ComponentFixture<DefectsChartComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DefectsChartComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DefectsChartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
