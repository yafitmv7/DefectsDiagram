import { ChangeDetectorRef, Component, OnDestroy, OnInit } from '@angular/core';
import { Observable, Subscription } from 'rxjs';
import { tap } from 'rxjs/operators';
import { Defect } from '../model/defect';
import { DefectsListService } from '../services/defects-list.service';

@Component({
  selector: 'app-defects-table',
  templateUrl: './defects-table.component.html',
  styleUrls: ['./defects-table.component.css']
})
export class DefectsTableComponent implements OnDestroy {
  defects$: Observable<Defect[]> | undefined;
  selectedDefect!: Defect;
  subscription: Subscription;


  constructor(private defectsListService: DefectsListService, private cdr: ChangeDetectorRef) {
    this.defects$ = this.defectsListService.getDefects();

    this.subscription = this.defectsListService.getSelectedDefect().subscribe(selected => {
      if (selected) {
        this.selectedDefect = selected;
        // console.log('this.selectedDefect', this.selectedDefect)
        cdr.detectChanges();
      }
    });
  }

  onRowSelect(event: any) {
    this.defectsListService.setSelectedId(event.data.uuid);
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }
}
