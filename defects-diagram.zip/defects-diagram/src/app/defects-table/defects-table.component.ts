import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { tap } from 'rxjs/operators';
import { Defect } from '../model/defect';
import { DefectsListService } from '../services/defects-list.service';

@Component({
  selector: 'app-defects-table',
  templateUrl: './defects-table.component.html',
  styleUrls: ['./defects-table.component.css']
})
export class DefectsTableComponent implements OnInit {
  defects$: Observable<Defect[]> | undefined;
  selectedDefect!: Defect;

  defects?: Defect[];

  constructor(private defectsListService: DefectsListService) { }

  ngOnInit(): void {
    this.defects$ = this.defectsListService.getDefects();

    this.defectsListService.getSelectedDefect().subscribe(selected => {
      if (selected) {
        this.selectedDefect = selected;
        console.log('this.selectedDefect', this.selectedDefect)
      }
    })

  }

  onRowSelect(event: any) {
    this.defectsListService.setSelectedId(event.data.uuid);
  }



}
