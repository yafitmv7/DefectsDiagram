import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DefectsTableComponent } from './defects-table.component';

describe('DefectsTableComponent', () => {
  let component: DefectsTableComponent;
  let fixture: ComponentFixture<DefectsTableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DefectsTableComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DefectsTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
