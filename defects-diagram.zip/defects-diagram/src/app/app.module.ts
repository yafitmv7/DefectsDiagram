import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { DefectsTableComponent } from './defects-table/defects-table.component';
import { EditSeverityComponent } from './edit-severity/edit-severity.component';
import { NgChartsModule } from 'ng2-charts';
import { DefectsChartComponent } from './defects-chart/defects-chart.component';
import { HttpClientModule } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {TableModule} from 'primeng/table';
import {ButtonModule} from 'primeng/button';
import {SliderModule} from 'primeng/slider';
import { FormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    AppComponent,
    DefectsTableComponent,
    EditSeverityComponent,
    DefectsChartComponent,

  ],
  imports: [
    BrowserModule,
    NgChartsModule,
    HttpClientModule,
    BrowserAnimationsModule,
    TableModule,
    ButtonModule,
    SliderModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
