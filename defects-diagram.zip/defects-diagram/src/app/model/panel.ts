export interface Panel {
    width: number;
    height: number;
}