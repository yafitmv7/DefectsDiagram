import { Defect } from "./defect";

export interface DefectList {
    defects: Defect[];
    selectedDefectId: string | null;
}