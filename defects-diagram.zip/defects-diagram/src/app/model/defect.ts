export interface Defect {
    uuid: string;
    x: number;
    y: number;
    severity: number;
}