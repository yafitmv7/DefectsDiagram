import { TestBed } from '@angular/core/testing';

import { GenerateDefectsService } from './generate-defects.service';

describe('GenerateDefectsService', () => {
  let service: GenerateDefectsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(GenerateDefectsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
