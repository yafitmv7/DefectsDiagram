import { Injectable } from '@angular/core';
import { v4 as uuid } from 'uuid';
import { Defect } from '../model/defect';

@Injectable({
  providedIn: 'root'
})
export class GenerateDefectsService {
  private readonly _nObjects = 100;

  readonly minSeverity = 10;
  readonly maxSeverity = 100;

  constructor() { }

  getDefects(maxHeight: number, maxWidth: number): Defect[] {
    let list: Defect[] = [];
    for (let i = 0; i < this._nObjects; i++) {
      list.push({
        uuid: uuid(),
        x: this.getRandomInt(0, maxWidth),
        y: this.getRandomInt(0, maxHeight),
        severity: this.getRandomInt(this.minSeverity, this.maxSeverity)
      });
    }
    return list;
  }

  private getRandomInt(min: number, max: number) {
    min = Math.ceil(min);
    max = Math.floor(max);
    return Math.floor(Math.random() * (max - min + 1) + min);
  }
}
