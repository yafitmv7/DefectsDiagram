import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable, of } from 'rxjs';
import { filter, map, pluck, tap } from 'rxjs/operators';
import { DefectList as DefectsList } from '../model/defect-list';
import { Panel } from '../model/panel';
import { GenerateDefectsService } from './generate-defects.service';
import { Defect } from '../model/defect';

@Injectable({
  providedIn: 'root'
})
export class DefectsListService {
  private defectsList$: BehaviorSubject<DefectsList>;

  constructor(private httpClient: HttpClient,
    private generateService: GenerateDefectsService) {

    // Initialize defects list with default value
    this.defectsList$ = new BehaviorSubject<DefectsList>({ defects: [], selectedDefectId: null });

    this.initData();
  }

  private initData() {
    this.getPanel().subscribe(panel => {
      const defects = this.generateService.getDefects(panel.height, panel.width);
      let defectsList: DefectsList = { defects, selectedDefectId: null };
      this.setDefectsList(defectsList);
    },
      _ => {
        console.error('Defects data could not be loaded.');
      });
  }


  private setDefectsList(defectsLst: DefectsList) {
    this.defectsList$.next(defectsLst);
  }

  getPanel(): Observable<Panel> {
    return this.httpClient.get<Panel>('/assets/panel.json').pipe(
      // tap (panel => this.panel = panel)
    );
  }


  getDefects(): Observable<Defect[]> {
    return this.defectsList$.pipe(
      pluck('defects')
    );
  }

  getSelectedId(): Observable<string | null> {
    return this.defectsList$.pipe(
      pluck('selectedDefectId')
    );
  }


  setDefectSeverity(uuid: string, severity: number) {
    const defectsList: DefectsList = { ...this.defectsList$.value };
    defectsList.defects = defectsList.defects.map(def => {
      def.severity = (def.uuid === uuid) ? severity : def.severity;
      return def;
    })
    this.defectsList$.next(defectsList);
  }

  setSelectedId(uuid: string) {
    const defectsList: DefectsList = {
      ...this.defectsList$.value,
      selectedDefectId: uuid
    };
    this.setDefectsList(defectsList);
  }

  getSelectedDefect(): Observable<Defect | undefined> {
    return this.defectsList$.pipe(
      map(({ defects, selectedDefectId }) => {
        const idx = defects.findIndex(d => d.uuid === selectedDefectId);
        if (idx > -1) {
          return defects[idx];
        } else {
          return undefined;
        }
      }));
  }

}

