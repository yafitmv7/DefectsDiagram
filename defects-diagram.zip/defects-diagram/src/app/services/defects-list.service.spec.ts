import { TestBed } from '@angular/core/testing';

import { DefectsListService } from './defects-list.service';

describe('DefectsListService', () => {
  let service: DefectsListService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(DefectsListService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
